package methodref;

interface a{
	void message(String message);
}



public class Refcons {

	public Refcons(String mess) {
	System.out.println(mess);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		a A = Refcons::new;
		A.message("hello");

}
}
