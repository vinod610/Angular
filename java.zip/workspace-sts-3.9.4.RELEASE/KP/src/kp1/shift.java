package kp1;

import java.time.LocalDateTime;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

public class shift {
	public static LocalTime time = LocalTime.parse("00:00");
	public static LocalDate dt= LocalDate.parse("1");
	public static LocalDateTime ldt =LocalDateTime.of(2020, 8, 01, 00, 00);
	public static LocalDateTime ldt1 =LocalDateTime.of(2020, 8, 05, 00, 00);
	
	
	
	
	
shift sh = new shift();


public static LocalTime claculateShift() {
	for(int i=0; i<=40; i++) {
		dt=dt.plusDays(1);
		time=time.plusHours(2);
		System.out.println(dt);
		
	}
	return time;
}

}