package methodref;

interface ref{
	void say();
}


public class M1 {

	public static int rty() {
		System.out.println("sdusdushiu");
		return 2;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		M1 Ref = new M1();
		ref Ref1 = M1::rty;
		Ref1.say();
		
	}

}
