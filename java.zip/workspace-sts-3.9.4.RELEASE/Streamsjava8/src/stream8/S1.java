package stream8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.stream.Collectors;

public class S1 {
static long count;
static List filtered;
static String merged;
static List m;
static IntSummaryStatistics n;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<String> list = Arrays.asList("ab","","b","c","","");
List<Integer> list1 = Arrays.asList(4,3,2,1);
//List<String> listr = new ArrayList();

//System.out.println(list);
count =list.stream().filter(string->string.isEmpty()).count();
System.out.println(count);
count = list.stream().filter(string->string.length()==2).count();
System.out.println(count);

filtered =list.stream().filter(string->!string.isEmpty()).collect(Collectors.toList());
System.out.println(filtered);

merged = list.stream().filter(string->!string.isEmpty()).collect(Collectors.joining("delimiter"));
System.out.println(merged);

m= list1.stream().map((i)->i*i).peek(i->System.out.println("" + i)).collect(Collectors.toList());
System.out.println(m);


n=list1.stream().mapToInt((i)->i).summaryStatistics();
System.out.println(n);


count = list.parallelStream().filter(string->string.length()==2).count();
System.out.println(count);
	}

}
