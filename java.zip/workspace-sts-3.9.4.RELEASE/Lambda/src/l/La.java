package l;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import l.car;
public interface La {

	static String name2="baboii";
//	 default String call(Object obj) {
//		 
//		 return "hello";
//	 }

	public static void call(car ca) {
		
		ArrayList<Integer> lis = new ArrayList<>();
		lis.add(123);
		lis.add(456);
		lis.add(789);
		System.out.println(ca+"8888888888888888888");
		//ca.color
		//if(ca.color.contains("lll")) {
		//List l;
		System.out.println("before going to car functional interface");
		
		for(int l: lis) {
		 
		ca.accept(lis);
		}
		
		System.out.println("babai");
	//}
	}
	
//	static String call1() {
//		return"hello";
//	}
}
