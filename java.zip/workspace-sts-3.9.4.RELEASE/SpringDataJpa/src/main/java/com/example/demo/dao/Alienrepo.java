package com.example.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Alien;
import java.util.List;
//import antlr.collections.List;

public interface Alienrepo extends JpaRepository<Alien, Integer>{

}
