package l;

public class Pom implements Comparable<Pom>{
	
	public int name;
	public int name2;
	
	public Pom(int n, int n1) {
		this.name = n;
		this.name2 = n1;
		System.out.println(n +"n1 is "+ n1);
	}
	
	

	
	public int compareTo(Pom o) {
		// TODO Auto-generated method stub
	int i = 	this.name<this.name2 ? -1 : this.name==this.name2 ?0:-1;
		System.out.println(i);
		return 1;
	}

}
