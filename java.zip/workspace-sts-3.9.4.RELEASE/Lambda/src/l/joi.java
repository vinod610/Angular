package l;

import java.io.IOException;
import java.sql.Date;

public class joi {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		
		try {
			
		
     String date = "03/15/2020";
    int pos1=date.indexOf("/");
    int pos2=date.lastIndexOf("/");
    //System.out.println(pos1+"  --> "+date.substring(0,pos1));
    
    //System.out.println(pos2+" --> "+date.substring(pos2+1));
    //System.out.println("Date -->"+date.substring(pos1+1, pos2));
    String str= date.substring(pos2+1) +"-"+date.substring(0,pos1)+"-"+date.substring(pos1+pos2);
    String str1=date.substring(pos2+1);
    //System.out.println(pos1 );
    //System.out.println(pos2);
    //System.out.println(str);
    System.out.println(date.substring(6, 10));
		}
		catch(Exception io) {
			
		}
		
    // String d =date.substring(0,10);
     //String d1=date.substring(3,5);
     //String d2= date.substring(6,10);
     //System.out.println(d);
     //System.out.println(d1);
     //System.out.println(d2);
	}

	

}
