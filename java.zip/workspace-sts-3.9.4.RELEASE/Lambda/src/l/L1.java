package l;

import java.util.ArrayList;

interface function1{
	public void fun();
}


interface function2{
	public void fun1(int x);
}


public class L1 {
	ArrayList list = new ArrayList();

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		function1 f = ()->{System.out.println("lambda");};
		function2 f2 =a->{System.out.println(a*a);};
		f2.fun1(2);
		
		f.fun();
		
	}

}
