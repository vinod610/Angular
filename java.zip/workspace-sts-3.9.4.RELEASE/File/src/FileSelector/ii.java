package FileSelector;

public class ii {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
String file ="book.pdf";
int x = file.lastIndexOf("9");
file = file.substring(x+1);
System.out.println(file + "}}}}}}}}}}}}}");
System.out.println(x);
String filename = file.substring(file.lastIndexOf(".")+1);
String check ="^.+(\\."+filename.toLowerCase() +"|\\."+ filename.toUpperCase()+")$";
System.out.println(check);
System.out.println(filename + "iidjifjidij");
		
	}

}
