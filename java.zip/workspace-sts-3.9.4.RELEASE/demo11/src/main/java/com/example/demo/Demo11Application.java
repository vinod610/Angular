package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class Demo11Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext context =SpringApplication.run(Demo11Application.class, args);
	Alien a= 	context.getBean(Alien.class);
	a.demo();
	a.demo1();
	}

}
