package l;

import java.util.ArrayList;
import l.car;
public class Arraylist {

	static String name="reddy";
	static String num="123";
	static int count=0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> list = new ArrayList<>();
		list.add("name");
		list.add("address");
		list.add("city");
		
		ArrayList <String> list1 = new ArrayList<>();
		
		list.forEach((w)->{System.out.println(w);});
		
		La.call((name)->{
			int hh=0;
			for(int i=0; i<=4; i++) {
				
			hh+=1;
			System.out.println(hh);
			}
			
			System.out.println(name);});
		//La.call1();
		
		//la.call(()->{System.out.println("hello");});
		
			
		}
		
	}


