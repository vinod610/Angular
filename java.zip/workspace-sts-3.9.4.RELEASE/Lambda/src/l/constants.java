package l;

import java.util.regex.Pattern;

public class constants {

	
	final static Pattern REGX = Pattern.compile("^([a-zA-Z0-9]+)$");
	
	
}
