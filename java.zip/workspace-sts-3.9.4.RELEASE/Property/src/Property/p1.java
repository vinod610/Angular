package Property;
import java.util.Properties;
import java.util.stream.*;
import java.io.*;
public class p1 {

	
		// TODO Auto-generated method stub
		public static void main(String args[]) throws IOException {
		      Properties prop = readPropertiesFile("config.properties");
		    String key =  prop.getProperty("User");
		     System.out.println("username: "+ prop.getProperty("User"));
		     System.out.println(key);
		     // System.out.println("password: "+ prop.getProperty("password"));
		   }
		   public static Properties readPropertiesFile(String fileName) throws IOException {
		      FileInputStream fis = null;
		      Properties prop = null;
		      try {
		         fis = new FileInputStream(fileName);
		         prop = new Properties();
		         prop.load(fis);
		      } catch(FileNotFoundException fnfe) {
		         fnfe.printStackTrace();
		      } catch(IOException ioe) {
		         ioe.printStackTrace();
		      } finally {
		         fis.close();
		      }
		      return prop;
		   }
		

	}


