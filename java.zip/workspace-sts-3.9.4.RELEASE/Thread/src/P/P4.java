package P;



class g implements Runnable{
	public void run() {
		for(int i=0;i<=2;i++) {
			System.out.println("rrrrr");
			 try {
		    	  Thread.sleep(1000);
		      }
		      catch(Exception e) {
		    	  
		      }
		}
	}
}
public class P4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Runnable r = new Runnable() {
      public void run() {
  		for(int i=0; i<=2;i++) {
  			System.out.println("weeeeee");
  			 try {
  		    	  Thread.sleep(1000);
  		      }
  		      catch(Exception e) {
  		    	  
  		      }
  		}
  	}
      g y = new g();
      Thread t = new Thread(r);
      Thread t1 = new Thread(y);
      t.start();
      try {
    	  Thread.sleep(10);
      }
      catch(Exception e) {
    	  
      }
      t1.start();
	}

}
