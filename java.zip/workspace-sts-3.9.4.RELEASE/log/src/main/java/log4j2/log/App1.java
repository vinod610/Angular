package log4j2.log;

public class App1 {

	
	public  String getNum() {
		
		
		return "babai";
	}
		
	
	
}
