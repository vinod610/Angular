package reg;

import java.util.regex.Pattern;

public class R2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Pattern pattern = Pattern.compile("^([a-zA-Z0-9._@~# `| $!,:'?;=\\\\* -\\/ \\[\\{\\]\\}\\n\\r/]+)$");

String pass = "guu&";

if(pattern.matcher(pass).matches()) {
	System.out.println("success");
	
}
else {
	System.out.println("failure");
}
	}

}
