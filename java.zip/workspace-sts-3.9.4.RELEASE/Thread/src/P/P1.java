package P;


class A extends Thread{
	public void run() {
		for(int i=0;i<=5;i++) {
			try {
			
			System.out.println("hi");
			Thread.sleep(1000);
			}
			catch (Exception e) {
				
			}
		}
	}
}


class B extends Thread{
	public void run() {
		for(int i=0; i<=5;i++) {
			try {
				
				System.out.println("hello");
				Thread.sleep(1000);
				}
				catch (Exception e) {
					
				}
			
		}
	}
}


public class P1{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	A t = new A();
	B t1 = new B();
	t.start();
	try {
		Thread.sleep(10);
	}
	catch(Exception e) {
		
	}
	t1.start();
		
	}

}
