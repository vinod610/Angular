package k;

import java.util.regex.Pattern;

public class M {
public static Pattern pattern = Pattern.compile("abc\\(");
	public static void main(String[] args) {
		// TODO Auto-generated method stub
String k ="abc";
boolean j = pattern.matcher(k).matches();
System.out.println(j);
	}

}
