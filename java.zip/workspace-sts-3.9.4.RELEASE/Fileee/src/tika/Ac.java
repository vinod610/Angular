package tika;

import java.io.File;

import javax.activation.MimetypesFileTypeMap;

public class Ac {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String fileName = "/path/to/file";
		MimetypesFileTypeMap mimeTypesMap = new MimetypesFileTypeMap();

		// only by file name
		//String mimeType = mimeTypesMap.getContentType(file);

		// or by actual File instance
		File file = new File("epylint.bat");
		String mimeType = mimeTypesMap.getContentType(file);
		System.out.println(mimeType);
	}

}
