package l;

import java.util.regex.Pattern;

public class Valid {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		
		String value = "abcd";
		
		if(constants.REGX.matcher(value).matches()) {
			System.out.println("success");
		}
		else {
			System.out.println("failure");
		}
	}

}
