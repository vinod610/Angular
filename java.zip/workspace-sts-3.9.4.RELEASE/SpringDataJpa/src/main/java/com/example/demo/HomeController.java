package com.example.demo;

import java.util.List;

//import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.dao.Alienrepo;
import com.example.demo.model.Alien;

@Controller
public class HomeController {
	@Autowired
Alienrepo repo;
	@RequestMapping("/")
	public String home() {
		return "login.jsp";
	}
@RequestMapping("/addalien")
public String alien(Alien alien) {
	repo.save(alien);
	return "";
	
}
//@RequestMapping("/alien")
//@ResponseBody
//public String getalien() {
	/*ModelAndView mv = new ModelAndView("home.jsp");
	//Optional<Alien> alien = repo.findById(id);
	Alien alien = repo.findById(id).orElse(new Alien());
	System.out.println(repo.findByTech(123));
	mv.addObject(alien);
	//mv.setViewName("home.jsp");
	return mv;
//	return "home.jsp";
 * 
*/
//	return repo.findAll().toString();
//}


@RequestMapping("/alien")
@ResponseBody
public List<Alien> getalien() {
	return repo.findAll();
	//return "home.jsp";
}

@RequestMapping("/aliens/123")
@ResponseBody
public String getaliens() {
	return repo.findById(123).toString();
	//return "home.jsp";
}
}