package robot;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import javax.activation.MimetypesFileTypeMap;

public class R1 {
static boolean robo;
static int i=0;
	public static void main(String[] args) throws Exception  {
		// TODO Auto-generated method stub
String f = "123.pptx";

File f1 = new File(f);
MimetypesFileTypeMap fileTypeMap = new MimetypesFileTypeMap();
String mimeType = fileTypeMap.getContentType(f1);
System.out.println(mimeType + "checkingggggggggggg");
FileInputStream fis = new FileInputStream(f1);
if(true) {
robo= robotcheck(fis);
}
if(true) {
	System.out.println(robo + "global value");
}
System.out.println(robo+ "ufduehfiuehfiuehfiefi");
//InputStreamReader is = new InputStreamReader(fis);
//BufferedReader br = new BufferedReader(is);
//String line="";
//while((line=br.readLine())!=null) {
//	
//		System.out.println( line );
//		if(line.contains("User-agent:")) {
//			System.out.println(line + "gettinghishis");
//		}
////		System.out.println("getting");	
//}
//
//
//br.close();
	}

	
	public static boolean robotcheck(FileInputStream fi) {
		try {
		InputStreamReader is = new InputStreamReader(fi);
		BufferedReader br = new BufferedReader(is);
		String line="";
		while((line=br.readLine())!=null) {
		
		 i =i+1;
		
				
				if(line.contains("User-agent:")) {
					System.out.println( line +i );
					System.out.println(" does  containgettinghishis"+ i);
					return true;
				}
//				System.out.println("getting");	
		}


		br.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		

return false;
	}
}
