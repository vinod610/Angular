package File;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.util.Properties;

public class out {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
FileWriter ou= new FileWriter("config.properties");
Properties pr = new Properties();
//pr.write(ou);

// int i =9;
//String s ="ffgff";
 ou.write("kufkvcdifdnginignfd");
 //byte[] b = s.getBytes();
 //ou.write(b);
ou.close();
 System.out.println("sucess");

	}

}
