package Zip;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.List.*;
import java.util.zip.*;
import java.util.zip.ZipFile;
import javax.activation.*;

import org.apache.tika.Tika;
import org.apache.tika.detect.Detector;
import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.Parser;
import org.apache.tika.sax.BodyContentHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

public class Z1 {

	//String fileExtensions = ",zip,txt,exe,";
	String file1  = ",zip,exe,txt,";
	
	
	
	public static String getFileExtension(String fileName) {
		if(fileName!=null && fileName.lastIndexOf('.')>0) {
			return fileName.substring(fileName.lastIndexOf('.')+1,fileName.length());
			
		}
	return "";
	}
	public String printnFIle(String filepath) throws SAXException, TikaException  {
		InputStream in = null;
     	FileInputStream fin = null;
     ZipInputStream zin = null;
 	 ZipEntry zip = null;
	  try {
//		  MimetypesFileTypeMap mimetype = new MimetypesFileTypeMap();
//		  String mime = mimetype.getContentType(filepath);
//		  System.out.println(mime);
		  ZipFile z = new ZipFile(filepath);
		  Enumeration<?> enu = z.entries();
		  while(enu.hasMoreElements()) {
			  zip = (ZipEntry) enu.nextElement();
			  String name = zip.getName();
			  System.out.println(name);
			  in = z.getInputStream(zip);
			  System.out.println(in);
			  
		  }
	    	 fin = new FileInputStream(filepath);
	    	 System.out.println("reading started");
	    	 zin = new ZipInputStream(new BufferedInputStream(fin));
	    	 System.out.println("zip reading started");
	    	while( (zip = zin.getNextEntry())!=null) {
	    		System.out.println("inside while loop");
	    	String file = zip.toString();
	    	Tika tika = new Tika();
	    	String k = tika.detect(file);
	    	System.out.println(k+"********************************");
	    	ContentHandler contenthandler = new BodyContentHandler();
            Metadata metadata = new Metadata();
            metadata.set(Metadata.RESOURCE_NAME_KEY, file);
            Parser parser = new AutoDetectParser();
            // OOXMLParser parser = new OOXMLParser();
            parser.parse(zin, contenthandler, metadata);
            System.out.println("Mime: " + metadata.get(Metadata.CONTENT_TYPE));
	    	 //AutoDetectParser parser = new AutoDetectParser();
	           //Detector detector = parser.getDetector();
	           //Metadata md = new Metadata();
	           //md.add(Metadata.RESOURCE_NAME_KEY, file);
	           //MediaType mediaType = detector.detect(zin, md);
	           //System.out.println(mediaType);
	    	String filecheck = getFileExtension(file);
	    	System.out.println(filecheck);
	    	//System.out.println(file);
	    		//if ( zip.toString() ) {
//	    	if(file.toLowerCase().endsWith("zip")){
//	    		return printnFIle(file);
//	    	}
//	    	System.out.println("just before zip check");
	    	if(filecheck.equals("zip") ) {
	    		System.out.println("checking zipppppp");
	    		return printnFIle(file);
	    		//System.out.println("checked the zip");
	    	}
	    		//return printnFIle(file);
	    	
	    		if(filecheck!=null&& file1.contains(filecheck)) {
	    			System.out.println(file);
	    			
	    		}
	    		else {
	    			System.out.println("not a valid file");
	    		}
	    	//System.out.println(zip.getName());
//	    	zin.close();
//	    	System.out.println("whether zip is closed or not");
	    	 
	     }
	//  zin.close();
	  System.out.println("came out of while loop");
}
	  catch(IOException e){
		  e.printStackTrace(); 
	  }
	//catch(IoException e) {
		//e.printStackTrace();
	//}
	  return "";
	}
	public static void main(String[] args) throws Exception,SAXException {
		// TODO Auto-generated method stub
		  
       Z1 z = new Z1();
      // File file = new File("archive.zip.zip");
       z.printnFIle("C:\\vinod\\Tika\\juy.zip");
		//System.out.println("file uploaded");
		
	}
   
	
}
