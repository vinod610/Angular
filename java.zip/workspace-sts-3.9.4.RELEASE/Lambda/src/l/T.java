package l;

public class T {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Runnable r =()->{System.out.println("thread started");};
Thread t = new Thread(r);
t.start();
	}
}
