package l;

import java.util.ArrayList;
import java.util.Collections;

public class Comp  {
	
	 
	public static void main(String[] as) {
		// TODO Auto-generated method stub
     
		ArrayList<Pom> p = new ArrayList<Pom>();
		p.add(new Pom(1,3));
		p.add(new Pom(2, 3));
	
	Collections.sort(p);
	}

	
	}
	


