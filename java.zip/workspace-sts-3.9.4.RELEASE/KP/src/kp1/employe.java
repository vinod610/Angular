package kp1;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
public class employe {
 public double desiredearnings;
	int min=30;
	int max=90;
	static int b;
   Random rd = new Random();
	static List<employe> emp = new ArrayList<employe>();//new employe();
	employe e = new employe();
	

	public static employe desiredearnings(int min) {
		
		System.out.println(emp.size());
		int min1=30;
		for(int i=0;i<=10;i++) {
			System.out.println("came to for loop");
			if(min<=90) {
				System.out.println("came to if loop");
		 min=min+5;
		 System.out.println(min);
		//System.out.println(b);
			}
			else {
				System.out.println("go goa gone");
			}
		
		}
		return emp;
		
	}
}
