package k;

public class K1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String k="";

if(k==null){
	System.out.println("true");
}
else 
	System.out.println("false");

	}

}
