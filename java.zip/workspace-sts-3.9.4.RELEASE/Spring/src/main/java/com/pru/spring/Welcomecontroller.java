package com.pru.spring;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.pru.spring.HomeController;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Welcomecontroller {
	public static final Logger logger = Logger.getLogger(Welcomecontroller.class);
	@RequestMapping(value="/welcome",method=RequestMethod.GET)
	public ModelAndView welcome(HttpServletRequest req, HttpServletResponse res) {
		String name = req.getParameter("name");
		String i = req.getParameter("id");
		String s =(String) req.getSession().getAttribute("csrf");
		logger.debug(s);
		//System.out.println(s);
		//System.out.println(name + i + "hhidhiwhdiwhiwiw");
		logger.info(name + "7777777777777777777777");
		ModelAndView m = new ModelAndView();
		m.addObject("Name",name);
		m.addObject("CSRF", s);
		m.setViewName("home");
		return m;
		//return new ModelAndView("Name");
	}

}
