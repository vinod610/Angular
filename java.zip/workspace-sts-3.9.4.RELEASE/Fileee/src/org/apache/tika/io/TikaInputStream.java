package org.apache.tika.io;

import java.io.File;
import java.io.InputStream;

public class TikaInputStream {

	public static InputStream get(File file) {
		// TODO Auto-generated method stub
		return null;
	}

}
