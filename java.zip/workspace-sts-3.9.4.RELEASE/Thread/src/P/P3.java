package P;

public class P3 extends P2 {

	public  void run() {
		//super.run();
		System.out.println("uguhdi");
	}
	
	public static void yut() {
		System.out.println("ucdius");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
P2 p = new P3();

p.run1();
	}

}
