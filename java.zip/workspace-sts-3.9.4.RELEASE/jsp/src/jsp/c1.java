package jsp;

public class c1 {

	String name;
	String date;
	
	public String getName() {
		return name;
		
	}
	public void setName(String name) {
		name =name;
		
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		date =date;
	}
}
