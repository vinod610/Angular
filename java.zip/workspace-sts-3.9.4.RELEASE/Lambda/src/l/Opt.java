package l;

import java.util.Optional;

public class Opt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String ar[] = new String[5];
		
	Opt o = new Opt();
	
	Opt.g(ar);
	}
	
	public static String g (String []a) {
		
		
		Optional<String> k  = Optional.ofNullable(a[4]);
		if(k.isPresent())
		System.out.println(k);
		System.out.println("no balure");
		//return k;
		
			return "hidhfi";
	}
	

}
