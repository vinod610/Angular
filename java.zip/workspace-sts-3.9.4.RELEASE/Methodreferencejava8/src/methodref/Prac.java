package methodref;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class Prac {
	
static FileInputStream in = null;
	public static void main(String[] args) throws Exception {
		
		// TODO Auto-generated method stub
		try {
 in = new FileInputStream("text");
 
 System.out.println(in.read());
		}
		catch(FileNotFoundException e) {
			System.out.println("noi fiel");
		}
	
		catch(IOException e) {
			System.out.println("noi fiel");
		}
	}

}
