package k;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;

import org.apache.tika.Tika;
import org.apache.tika.config.TikaConfig;
import org.apache.tika.detect.DefaultDetector;
import org.apache.tika.detect.Detector;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;
//import org.apache.tika.detect.ContainerAwareDetector;

public class H {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
//		int decimalExample = Integer.parseInt("6"); 
//        int signedPositiveExample = Byte.parseByte("$24"); 
//        int signedNegativeExample = Integer.parseInt("-20"); 
//        int radixExample = Integer.parseInt("20",16); 
//        int stringExample = Integer.parseInt("ge1ek",29); 
  String f = "ad.properties";
  File f1 = new File(f);
  FileInputStream fi = new FileInputStream(f1);
  BufferedInputStream bf = new BufferedInputStream(fi);
  Tika k = new Tika();
  String type = k.detect(f);
  System.out.println(type);
  TikaConfig tika = new TikaConfig();
Detector detector = new DefaultDetector();
  Metadata metadata = new Metadata();
  metadata.set(Metadata.RESOURCE_NAME_KEY, f);
  MediaType mimetype = detector.detect(TikaInputStream.get(bf), metadata);
  System.out.println(mimetype);
		  
//        System.out.println(decimalExample); 
//        System.out.println(signedPositiveExample); application/vnd.openxmlformats-officedocument.presentationml.presentation
//        System.out.println(signedNegativeExample); pplication/vnd.openxmlformats-officedocument.presentationml.presentation
//        System.out.println(radixExample); 
//        System.out.println(stringExample); 
	}

}
