package k;

import java.io.FileInputStream;
import java.util.Properties;

public class K2 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
String t = "60845912619691053937666873127194851";
String[] st = t.split("   ");
byte[] bytes = new byte[st.length];
for(int i=0; i<bytes.length;i++) {
	bytes[i]=(byte)Byte.parseByte(st[i]);
	System.out.println(bytes[i]);
}
System.out.println(st);
//Properties p = new Properties();
//FileInputStream fi = new FileInputStream("ad.properties");
// p.load(fi);
//String h = p.getProperty("cipherkey");
//System.out.println(h);
	}

}
