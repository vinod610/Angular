package com.pru.spring;

public class Model {

	public String name;
	public int id;
	
	public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name =name;
	}
	
}
