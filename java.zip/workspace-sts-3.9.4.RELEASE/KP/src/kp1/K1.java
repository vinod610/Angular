package kp1;
import kp1.employe;
import kp1.shift;
public class K1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ab = employe.desiredearnings(30);
		  System.out.println(shift.claculateShift());
		  employe.emp.add(employe.desiredearnings(30));
		  
	}

}
