package Patte;

import java.util.regex.Pattern;

import org.apache.commons.text.StringEscapeUtils;

public class P1 {
static Pattern pattern = Pattern.compile("a-zA-Z0-9");
	public static void main(String[] args) {
		// TODO Auto-generated method stub
String val = "123a";
System.out.println(pattern);
//String key = "a-zA-Z0-9._@~#\\\"\\\"";
//
//String k = "i((bm";
//String a = StringEscapeUtils.escapeEcmaScript(k);
//System.out.println("ysfysgfudfud"+a);
//
//if(key.matches(pattern)) {
//	System.out.println("ok");
//}
//else {
//	System.out.println("mno tokj");
//}

if(pattern.matcher(val).matches()) {
	System.out.println("success");
}
else {
	System.out.println("failure");
}

	}

}

