package k;

import java.util.Enumeration;
import java.util.Vector;
import java.util.regex.Pattern;
//import org.apache.commons.codec.binary.Base64;
public class Test { 
	public static Pattern pat = Pattern.compile("^([a-zA-Z-0-9._@~#| !$,:'\"?;&=\\*-/ \\[\\{\\]\\}\\n\\r/]+)$");

    public static void main(String[] args) 
    { 
    String value="scrip<talert123script";
    Vector<String>vec = new Vector<String>();
    vec.add(value);
    boolean valid = appscan(vec);
    if(valid) {
    	System.out.println("pass");
    	
    }
    else {
    	System.out.println("fail");
    }
    
} 
    public static boolean appscan(Vector v) {
    	Enumeration num = v.elements();
    	while(num.hasMoreElements()) {
    		String va= (String) num.nextElement();
    		if(!va.isEmpty()) {
    			if(!pat.matcher(va).matches()) {
    		    	System.out.println("failded");
    		    	v=null;
    		    	return false;
    		    	
    		    }	
    			
    		}
    	}
    	System.out.println("pas");
    	return true;
    }
}