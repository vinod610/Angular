package l;

import java.util.ArrayList;
import java.util.List;

public class rec {

	public static void main(String[] args) {
		boolean r = true;
		// TODO Auto-generated method stub
//List<Integer> list = new ArrayList<Integer>();
//list.add(1);
//list.add(2);
//list.add(3);
//rec.add(list);
		String A1 ="bangalore";
		String A2 ="mangalore";
		
		for(int i=0; i<=1;i++) {
			
			 r = A1.substring(i,A1.length()).equalsIgnoreCase(A2.substring(i,A2.length())) ? true: false;
			 if(r)
				 System.out.println(A1.substring(i)  +   A2.substring(i));
		}

	}
	
//	public static int add(List<Integer>list) {
//		
//		list.forEach(e->System.out.println(e));
//		return rec.add(list);
//	}

}
