package m1;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class M1 {
static Map<String, String> mimetypes;

static Map<String, String > getMimetypes(){
	return mimetypes;
}
public void setmimetypes(Map<String , String> mimetypes) {
	this.mimetypes = mimetypes;
	
}
public static String getFileExtension(String fileName) {
	System.out.println(fileName);
	if(fileName!=null && fileName.lastIndexOf('.')>0) {
		return fileName.substring(fileName.lastIndexOf('.')+1,fileName.length());
		
	}
return "";
}
		   

public static boolean isFiletypeSupported(String fileName,String content)throws Exception{
	
	String fileExt = getFileExtension(fileName).toLowerCase();
	System.out.println(fileExt);
	String mimetype = getMimetypes().get(fileExt);
	if(mimetype!=null && mimetype.equalsIgnoreCase(content)) {
		System.out.println("true");}
		else {
			System.out.println("false");              
	
		}



	return true;
}
	public static void main(String[] args) throws Exception {
		
      ApplicationContext context =new ClassPathXmlApplicationContext("upload.xml");  
        M1 m = (M1)context.getBean("M1");
        
		//m.getMimetypes();
		
		String fileName= "reddy.txt";
		String content = "plain/text";
boolean check = isFiletypeSupported(fileName,content);

	}

}
