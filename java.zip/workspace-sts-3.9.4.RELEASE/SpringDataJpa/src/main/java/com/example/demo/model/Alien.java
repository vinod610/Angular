package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Alien {
	@Id
private int id;
private String name;
private int tech;
public int getTech() {
	return tech;
}
public void setTech(int tech) {
	this.tech = tech;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String toString() {
	
	System.out.println(id +    name + tech);
	return "";
}
}
