package Jchooser;
import java.io.File;
import java.io.FilenameFilter;
public class MyFileFilter {

	
		public static void main(String a[]) throws Exception{
	        File file = new File("C:/vinod/");
	        String[] files = file.list(new FilenameFilter() {
	             
	            @Override
	            public boolean accept(File dir, String name) {
	                if(name.toLowerCase().endsWith(".csv")){
	                	System.out.println("yvy");
	                    return true;
	                } else {
	                    return false;
	                }
	            }
	        });
	        for(String f:files){
	            System.out.println(f);
	        }
	}

}
