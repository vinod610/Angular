package l;

import java.util.ArrayList;
import java.util.List;

public interface car {

//	String name="BMW";
//	String color="black";
	
	void accept(ArrayList<Integer> list);
}
