package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class Laptop {

	private String brand;
	private String compiler;
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getCompiler() {
		return compiler;
	}
	public void setCompiler(String compiler) {
		this.compiler = compiler;
	}
	public String Compile() {
		System.out.println("tytft");
		return "";
	}
}
