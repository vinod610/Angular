package log4j2.log;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import  log4j2.log.Functional;
//import org.apache.logging.log4j.LoggerInterface;
import com.amazonaws.services.lambda.runtime.Context;
/**
 * Hello world!
 *
 */




public class App 
{
	
	
	static Logger log = LogManager.getLogger(App.class);
    public static void main( String[] args )
    {
    	
    	log.debug("commonnn");
    }


    
}
