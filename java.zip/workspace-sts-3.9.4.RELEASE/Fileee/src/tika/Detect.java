package tika;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.tika.Tika;
import org.apache.tika.detect.Detector;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;

public class Detect {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
     File f = new File("vin.pptx");
    String k =  f.getName();
    System.out.println(k);
     byte[] filecontent=null;
     Tika tik = new Tika();
     FileInputStream f1 = new FileInputStream(f);
     Metadata m = new Metadata();
     String h = tik.detect(f1);
     System.out.println(h+">>>>>>>>>>>>>");
     detectMimeType(f);
	}

public static String detectMimeType(final File file) throws IOException {
    InputStream tikaIS = null;
    try {
        tikaIS = TikaInputStream.get(file);
        System.out.println(tikaIS);
        final Metadata metadata = new Metadata();
        AutoDetectParser parser = new AutoDetectParser();
        Detector detector = parser.getDetector();
        System.out.println(detector.detect(tikaIS, metadata).toString());
        return detector.detect(tikaIS, metadata).toString();
    } finally {
        if (tikaIS != null) {
            tikaIS.close();
        }
    }
}
}