package k;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
//import java.util.Base64;
import java.util.Properties;
import java.util.ResourceBundle;

//import org.apache.commons.codec.binary.Base64;
import javax.xml.bind.DatatypeConverter;
import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import javax.security.auth.*;
public class K3 {
public static String Algorithm="AES";
public static  String character="UTF-8";
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		Properties p = new Properties();
		System.out.println(p+"dueudeuhiehire");
		FileInputStream fi=null;
		String d ="U2FsdGVkX1+52EJz3e89iZXW96QwEcf7";
		try {
			 fi = new FileInputStream("ad.properties");
			p.load(fi);
		}
		catch(FileNotFoundException e) {
			System.out.println("not found"+e);
		}
		catch(IOException ie) {
			System.out.println("io"+ie);
		}
		finally{
			try {
			fi.close();
			}
			catch(IOException i) {
			System.out.println("stream is closed");
		}
		}
//		try(FileInputStream fi = new FileInputStream("ad.properties")){
//			
//			 p.load(fi);
//			 fi.close();
//			 
//		}
//		catch(FileNotFoundException e) {
//			
//		}
//		catch(IOException e1) {
//			System.out.println("herro" + e1);
//		}
		// p.load(fi);
		String key = p.getProperty("cipherkey");
		System.out.println(key);
		// ResourceBundle bundle = ResourceBundle.getBundle("ad");
//String key = bundle.getString("cipherkey");
	      // print the text assigned to key "hello"
	   //   System.out.println("rebel" + bundle.getString("cipherkey"));
		String value ="J51236B";//77_100_72_-14_33_-25_0_-44_-35_-60_-126_-24_125_119_-92_-93
		String encrypted = encryption( value,  key);
		System.out.println("done man"+ encrypted);
		//String decrypted = decryption( encrypted,key);
		String decrypted = decryption( encrypted,key);
		System.out.println("decrypted value is" + decrypted);
	}

	
	public static String encryption(String value, String key)throws Exception {
		String str="";
		String enc="";
	try {
		SecretKeySpec secu = new SecretKeySpec(key.getBytes(character),Algorithm);
		System.out.println("checking key" + secu.toString());
	Cipher cipher = Cipher.getInstance(Algorithm);
	System.out.println(cipher);
	cipher.init(Cipher.ENCRYPT_MODE, secu);
	//(cipher.init(Cipher.ENCRYPT_MODE, secu));
	byte[] stringBytes=value.getBytes(character);
	System.out.println(Arrays.toString(stringBytes));
	byte[] raw = cipher.doFinal(stringBytes);
	System.out.println("22222222"+Arrays.toString(raw));
	for(int i=0;i <raw.length;i++) {
		str+= raw[i]+"_";
		
	}
	 enc = str.substring(0, str.length()-1);
	//byte[] enc1 = DatatypeConverter.parseBase64Binary(enc);
	System.out.println("encrypted value is" + enc);
	//return enc;
	}
	catch(Exception e) {
		System.out.println("goneee");
		
	}
return enc;
	}

public static String decryption(String value, String key) throws Exception {
	try {
	SecretKeySpec secu = new SecretKeySpec(key.getBytes(character),Algorithm);
	System.out.println("checking key" + secu.toString());
	System.out.println("going to byte");
	//byte[] ue2 = value.getBytes();
	//byte[] enc1 = DatatypeConverter.parseBase64Binary("OTE0MDQ5MTQyNzc3Nyo3");
	//System.out.println("^^^^^^^^^^^^^^^^^^^^^^^"+Arrays.toString(enc1));
	//String b = new String(enc1,character);
	//System.out.println("$$$$$$$$$$$$$$$$$"+b);
//	System.out.println(Arrays.toString(ue2)+ "888888888888888888888888");
	//String value1 = value.trim();
	//byte[] raw1 = value.getBytes(StandardCharsets.UTF_8);
	//System.out.println("%%%%%%%%%%%%%%"+ Arrays.toString(raw1));
	byte[] raw = StringToBytes(value);
	System.out.println("*******"+Arrays.toString(raw));
	System.out.println(raw);
	
	System.out.println("going to byte");
	Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
	cipher.init(Cipher.DECRYPT_MODE, secu);
	System.out.println("}}}}}}}}}}}}}}");
	byte[] fina = cipher.doFinal(raw);
	
	System.out.println("&&&&&&&&&&"+Arrays.toString(fina));
	String g = new String(fina,character);
	return g;
	}   //B@591f989e  [B@591f989e
	catch(Exception e) {
		System.out.println("dead");
	}
	return "";
}


public static byte[]  StringToBytes(String value1) {
	try {
	String[] strs = value1.split("_");
		
	System.out.println(strs.toString());
	byte[] bytes = new byte[strs.length];
	for(int i=0;i<bytes.length; i++) {
		System.out.println("came to for loop");
		 bytes[i] = (byte) Integer.parseInt(strs[i]);
	
	}
	return bytes;
	}
	catch(Exception e) {
		System.out.println("long dead");
	}
	System.out.println( new byte[0] + "ifieidwepppppppppppppppppppp");
	return new byte[0];
}

}

