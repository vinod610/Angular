package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Alien {
private String name;
private String id;
private int age;
@Autowired
private Laptop lap;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
	
public void demo() {
	System.out.println("vhsdhs");
}
public void demo1() {
	lap.Compile();
}
}
