package Property;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
public class p2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Properties prop = new Properties();
		prop.setProperty("Height", "2");
		prop.setProperty("weight", "23");
		prop.put("loss","3" );
		prop.setProperty("gygy", "98");
		
		try {
			FileOutputStream fo = new FileOutputStream("config.properties");
			prop.store(fo, "");
		}
		catch(IOException ex) {
			ex.printStackTrace();
			
			
		}
		
	}

}
