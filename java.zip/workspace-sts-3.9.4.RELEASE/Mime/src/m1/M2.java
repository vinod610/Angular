package m1;
import java.util.*;
public class M2 {

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map<String ,String> mimetypes = new HashMap<String, String>();
		
		mimetypes.put("txt", "plain/text");
		mimetypes.put("pdf","application/pdf");
		
	}

}
