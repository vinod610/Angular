package Property;
import java.io.*;
import java.util.Properties;
public class p3 {
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileInputStream fi= null;
		Properties pro = new Properties();
		try {
		 fi = new FileInputStream("config.properties");
		pro.load(fi);
		String key = pro.getProperty("Height");
		String key1 = pro.getProperty("weight");
		
		System.out.println(key + "  " +  key1);
		}
		catch(FileNotFoundException ex){
			ex.printStackTrace();
			
		}
		catch(IOException e) {
			System.out.println("io exception");
		}
finally {
	System.out.println("came to close inputstream");
	fi.close();
}
	}

}
