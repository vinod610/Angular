package P;

public class P2 {
	public static void run1() {
		System.out.println("suprt");
	}

	
	public  void run() {
		System.out.println("suprt");
	}
}
