package log4j2.log;

 interface Functional {
	
	void getNum();

}
