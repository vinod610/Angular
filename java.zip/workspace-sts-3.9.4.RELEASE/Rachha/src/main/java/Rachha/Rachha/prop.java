package Rachha.Rachha;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;

public class prop {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
InputStream read = new FileInputStream("src/config.properties");
		Properties pro = new Properties();
		pro.load(read);
	String url = pro.getProperty("db.password");
	System.out.println(url);
	}

}
