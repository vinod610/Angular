package tika;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.apache.tika.Tika;
import org.apache.tika.config.TikaConfig;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;

public class latest {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
String f = "123.pptx";
File f1 = new File(f);
FileInputStream fi = new FileInputStream(f1);
Tika k = new Tika();
String j = k.detect(fi,f);
System.out.println(j);
TikaConfig tika = new TikaConfig();

Metadata metadata = new Metadata();
metadata.set(Metadata.RESOURCE_NAME_KEY, f);
MediaType mimetype = tika.getDetector().detect(fi,metadata);
System.out.println(mimetype);
//TikaConfig tika = new TikaConfig();
////TikaInputStream ti = new TikaInputStream(f1);
//   Metadata metadata = new Metadata();
//   metadata.set(Metadata.RESOURCE_NAME_KEY, f1.toString());
//   String mimetype = tika.getDetector().detect(
//        TikaInputStream.get(fi), metadata);
//   System.out.println("File " + f + " is " + mimetype);
	}

}
