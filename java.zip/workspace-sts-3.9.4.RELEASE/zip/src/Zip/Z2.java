package Zip;

public class Z2 {
 static String name ="/";
	static String pattern = ",";
	static  boolean validation;
	
	public static  boolean validate(String name) {
		if(pattern.contains(name)) {
			//System.out.println(validation);
			return true;
		}
		return false;
	}
	
	public static void main( String[] args) {
		
		validation = validate(name);
		System.out.println(validation);
	}
}
