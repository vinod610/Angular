//package tika;
//
//import java.io.BufferedInputStream;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.io.InputStream;
//
//import org.apache.tika.Tika;
//import org.apache.tika.io.*;
//import org.apache.tika.config.TikaConfig;
//import org.apache.tika.detect.Detector;
//import org.apache.tika.metadata.Metadata;
//import org.apache.tika.mime.MediaType;
//import org.apache.tika.mime.MimeType;
//import org.apache.tika.parser.AutoDetectParser;
//import org.apache.tika.parser.Parser;
////import org.apache.tika.parser.microsoft.ooxml.OOXMLParser;
//import org.apache.tika.sax.BodyContentHandler;
//import org.xml.sax.ContentHandler;
//
//public class T1 {
//
//	public static  void main(String[] args) throws Exception {
//		// TODO Auto-generated method stub
//		//InputStream in = new 
//		String pathname1;
//		File f = new File("C:\\vinod\\Test\\");
//		//File f1 = new File("vin.pptx");
//		File[] getFile = f.listFiles();
//		System.out.println(getFile);
//		//pathnames=f.listFiles();
//		//System.out.println(pathnames);
//		for(File file :getFile) {
//      System.out.println(file);
//       Tika tika = new Tika();
//       MediaType mediatype = MediaType.parse(tika.detect(file));
//       String content = tika.detect(file);
//       System.out.println(content);
//       System.out.println(";;;;;;;;;;;;;;;;;;;" + mediatype);
//       InputStream is =null;
//       BufferedInputStream bis =null;
//       
//       
//       
//       try {
//    	   is = new FileInputStream(file);
//    	   bis = new BufferedInputStream(is);
//    	 //TikaInputStream it = TikaInputStream.get(file,md);
//    	  // TikaConfig config = TikaConfig.getDefaultConfig();
//           AutoDetectParser parser = new AutoDetectParser();
//           Detector detector = parser.getDetector();
//           Metadata md = new Metadata();
//           md.add(Metadata.RESOURCE_NAME_KEY, file.getName());
//           MediaType mediaType = detector.detect(bis, md);
//          // MimeType mimeType = config.getMimeRepository().forName(mediaType.toString());
//          // System.out.println(mimeType + "================================");
//           //String extension = mimeType.getExtension();
//           
//           System.out.println(mediaType);
//           System.out.println("^^^^^^^^^^^^^^^^^^" + mediaType.getSubtype());
//           
//           System.out.println("*********************");
//           
//           ContentHandler contenthandler = new BodyContentHandler();
// 	      
// 	      md.set(Metadata.RESOURCE_NAME_KEY, file.getName());
// 	      //metadata.add(Metadata.RESOURCE_NAME_KEY, file.getName());
// 	      Parser parser1 = new AutoDetectParser();
// 	      // OOXMLParser parser2 = new OOXMLParser();
// 	     parser1.parse(is, contenthandler, md);
// 	    // parser2.parse(is, contenthandler, md);
// 	    System.out.println("Mime: " + md.get(Metadata.CONTENT_TYPE));
// 	     
//       } finally {
//           try {
//               bis.close();
//           } catch (IOException e) {
//               
//           }
//       }
//       
//       
//       
//       
//       
//       
//       
//       
//       
//       
//       
//       
//       
//       //try {
//    	 //     is = new FileInputStream(file);
//         //     bis = new BufferedInputStream(is);
//    	      //ContentHandler contenthandler = new BodyContentHandler();
//    	      //Metadata metadata = new Metadata();
//    	      //metadata.set(Metadata.RESOURCE_NAME_KEY, file.getName());
//    	      //metadata.add(Metadata.RESOURCE_NAME_KEY, file.getName());
//    	      //Parser parser = new AutoDetectParser();
//    	      // OOXMLParser parser = new OOXMLParser();
//    	     // parser.parse(is, contenthandler, metadata);
//    	      //System.out.println("Mime: " + metadata.get(Metadata.CONTENT_TYPE));
//    	      //System.out.println("Title: " + metadata.get(Metadata.TITLE));
//    	      //System.out.println("Author: " + metadata.get(Metadata.AUTHOR));
//    	      //System.out.println("content: " + contenthandler.toString());
//    	      //System.out.println("--------------------------------------");
//    	    //}
//    	    //catch (Exception e) {
//    	      //e.printStackTrace();
//    	    //}
//    	    //finally {
//    //	        if (is != null) is.close();
//  //  	    }
////	}
//
//		}
//
//	
//	}
//}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
