//package tika;
//
//import java.io.BufferedInputStream;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.InputStream;
//
//import org.apache.tika.Tika;
//import org.apache.tika.detect.Detector;
//import org.apache.tika.metadata.Metadata;
//import org.apache.tika.mime.MediaType;
//import org.apache.tika.parser.AutoDetectParser;
//import org.apache.tika.parser.ParseContext;
//import org.apache.tika.parser.Parser;
//import org.apache.tika.parser.pdf.PDFParser;
//import org.apache.tika.sax.BodyContentHandler;
//import org.xml.sax.ContentHandler;
//
//public class T4 {
//
//	public static void main(String[] args)  throws Exception{
//		// TODO Auto-generated method stub
//		File f = new File("C:\\vinod\\Tika");
//		File f2 = new File("bld.bat");
//        File[] file = f.listFiles();
//        for(File f1 : file) {
//        	InputStream input = new FileInputStream(f1);
//        	BufferedInputStream bis = new BufferedInputStream(input);
//        	Tika tika = new Tika();
//        	String a = tika.detect(f2);
//        	System.out.println(a);
//        	ContentHandler contenthandler = new BodyContentHandler();
//            Metadata metadata = new Metadata();
//            metadata.set(Metadata.RESOURCE_NAME_KEY, f.getName());
//            Parser parser = new AutoDetectParser();
//            // OOXMLParser parser = new OOXMLParser();
//            parser.parse(bis, contenthandler, metadata);
//            System.out.println("Mime: " + metadata.get(Metadata.CONTENT_TYPE));
//            System.out.println("Title: " + metadata.get(Metadata.TITLE));
//            System.out.println("Author: " + metadata.get(Metadata.AUTHOR));
//            System.out.println("content: " + contenthandler.toString());
//          }
//        	
//        }
//	}
//
//
