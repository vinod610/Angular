package com.pru.spring;

import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class Interceptor extends HandlerInterceptorAdapter {
Pattern patern = Pattern.compile("a-z A-Z 0-9 . * $ #");
	public boolean preHandle(HttpServletRequest req, HttpServletResponse res,Object handler) {
		System.out.println("came to intercept");
		String name = req.getParameter("name");
		
		String i = req.getParameter("id");
	 
		System.out.println(name + i);
		
		
//		if(patern.matcher(name).matches()) {
//			System.out.println("appscan success");
//			return true;
//		}
//		else {
//			System.out.println("appscan failedx");
//			return false;
//		}
	return true;
	}
	
}
